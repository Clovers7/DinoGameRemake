

function Entering2()
{
    let nanp = document.getElementById("Namer").value;
    document.getElementById("startering").classList.add("displayn");
    setTimeout(function(){
        let output = document.getElementById("output2").innerHTML = "Welcome To The Game " + nanp;
        location.href = "main.html";
    },3000);
}

/*Building The Script That Can Move The Monster*/

/*https://www.w3schools.com/jsref/prop_element_classlist.asp Classlist was used a ton here so this is where I basically learned it from.*/

    var Monster = document.getElementById("Monster");
    var winner = true;
    //Call Variable
    function jump()
    {
        if(Monster.classList != "jump()"){
        Monster.classList.add("animatej");
        setTimeout(function(){
            Monster.classList.remove("animatej");
            var rando = parseInt(Math.random() * 3) + 1;
                if (rando == 1) {
                    document.getElementById("Prs").style.justifyContent = "center";
                } else if (rando == 2) {
                    document.getElementById("Prs").style.justifyContent = "left";
                } else {
                    document.getElementById("Prs").style.justifyContent = "right";
                }
        },300);

        }
    }

/*Monster getting caught on a block and getting stuck*/


        var dc = setInterval(function () {
            var Mtop = parseInt(window.getComputedStyle(Monster).getPropertyValue("top"));
            var Bleft = parseInt(window.getComputedStyle(Blocks1).getPropertyValue("left"));
            var Bleft2 = parseInt(window.getComputedStyle(Blocks2).getPropertyValue("left"));
            var Bleft3 = parseInt(window.getComputedStyle(Blocks3).getPropertyValue("left"));
            if (Bleft > 93 && Bleft < 143 && Mtop >= 350 || Bleft2 > -13 && Bleft2 < 143 && Mtop >= 350 || Bleft3 > 108 && Bleft3 < 138 && Mtop > 310) {
                winner = false;
                Blocks1.style.animation = "none";
                Blocks1.style.display = "none";
                Blocks2.style.animation = "none";
                Blocks2.style.display = "none";
                Blocks3.style.animation = "none";
                Blocks3.style.display = "none";
                document.getElementById("overlay").style.display = "block";
                document.getElementById("ending").style.display = "block";
                var i = parseInt((Math.random()*3)+1);
                if(i == 1)
                {
                    document.getElementById("anger").innerHTML = "Come on. This is Easy mode";
                }
                else if(i == 2)
                {
                    document.getElementById("anger").innerHTML = ":) You Can Always Close The Game";
                }
                else
                {
                    document.getElementById("anger").innerHTML = "Thats a Big L";
                }
            }
        }, 10)

/*Display Either Block1 Or Block2*/

var rl = setInterval(function() {
    var randomnum = parseInt((Math.random() * 3) + 1);
    if (randomnum == 1) {
        document.getElementById("Blocks2").classList.add("displayn");
        document.getElementById("Blocks3").classList.add("displayn");
        document.getElementById("Blocks1").classList.remove("displayn");
        document.getElementById("Blocks1").classList.add("as1");

    } else if (randomnum == 2) {
        document.getElementById("Blocks1").classList.add("displayn");
        document.getElementById("Blocks3").classList.add("displayn");
        document.getElementById("Blocks2").classList.remove("displayn");
        document.getElementById("Blocks2").classList.add("as1");

    }
    else
    {
        document.getElementById("Blocks1").classList.add("displayn");
        document.getElementById("Blocks3").classList.remove("displayn");
        document.getElementById("Blocks2").classList.add("displayn");
        document.getElementById("Blocks3").classList.add("as1");
    }
},1250)


/*Start The Game!*/

/*https://www.w3schools.com/js/tryit.asp?filename=tryjs_timing1 Very important link to advise.*/
function clicker()
{

}


function outter()
{

}

/*
document.getElementById("Prs").classList.remove("jc")
                        document.getElementById("Prs").classList.remove("jl")
                        document.getElementById("Prs").classList.add("jr")
 */


/*First Attempt to switch the blocks random sizes.*/

    /*
    let blocks1 = document.getElementById("Blocks1");
    function switcher()

    {
        var runner = parseInt(Math.random()*52) + 30;
        blocks1.style.setProperty('height', 'runner');
    }
/*



 /*This was in an attempt to somehow make it so that the blocks come out in 3 random sizes.*/

/*
var blocks1 = document.getElementById("Blocks1");
var blocks2 = document.getElementById("Blocks2");
var blocks3 = document.getElementById("Blocks3");
var i = 1;

        function randomblock()
    {
        while(i == 1) {
            var randomnum = parseInt(Math.random()*3)+1;
            if (randomnum == 1) {
                setTimeout(function(){
                    blocks1.style.removeProperty('display');
                },500);
            } else if (randomnum == 2) {
                setTimeout(function(){
                    blocks2.style.removeProperty('display');
                },500);
            } else{
                setTimeout(function(){
                    blocks3.style.removeProperty('display');
                },500);
            }
        }
    }
*/


/*A function initially intended to work for whtml an id for the whole html*/


/*
    function whtml(){
        var i = 0;
        if(Bleft>100 && Bleft<148 && Mtop >= 340 || Bleft2>-20 && Bleft2<148 && Mtop >= 340) {
            i++;
            if(i >= 3)
            {
                Blocks1.style.animation = "none";
                Blocks1.style.display = "none";
                Blocks2.style.animation = "none";
                Blocks2.style.display = "none";
                alert("Lost");
            }
        }
    }
*/

/*Unused function :(*/

/*
    function fly() {
    if(Monster.classList != "fly()"){
        Monster.classList.add("animatef");
        setTimeout(function(){
            Monster.classList.remove("animatef");
        },800);
    }
    }
*/

/*document.getElementById("realing").classList.add("displayn");
     document.getElementById("whtml").classList.add("dark");*/



